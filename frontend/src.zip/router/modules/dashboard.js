import DefaultLayout from '@/layouts/DefaultLayout.vue'
import ProjectOverview from '@/views/project/ProjectOverview.vue'

export default [
    {
        path: '/',
        component: DefaultLayout,
        children: [
            {
                path: '/projects/dashboard',
                name: 'ProjectOverview',
                component: ProjectOverview
            }
        ]
    }
]